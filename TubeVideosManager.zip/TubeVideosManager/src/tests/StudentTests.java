package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import tubeVideosManager.Genre;
import tubeVideosManager.Playlist;
import tubeVideosManager.TubeVideosManager;
import tubeVideosManager.Video;

/**
 * 
 * You need student tests if you are asking for help during
 * office hours about bugs in your code. Feel free to use
 * tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void testAddToPlaylist() {
		Playlist playlist = new Playlist("Test Playlist");
		boolean result = playlist.addToPlaylist("Test Video Title");
		assertTrue(result);
	}

	@Test
	public void testGetPlaylistVideoTitles() {
		Playlist playlist = new Playlist("Test Playlist");
		playlist.addToPlaylist("Test Video Title");
		ArrayList<String> titles = playlist.getPlaylistVideosTitles();
		assertEquals("Test Video Title", titles.get(0));
	}

	@Test
	public void testRemoveFromPlaylistAll() {
		Playlist playlist = new Playlist("Test Playlist");
		playlist.addToPlaylist("Test Video Title");
		playlist.addToPlaylist("Test Video Title Again");
		playlist.addToPlaylist("Test Video Title Again");
		playlist.removeFromPlaylistAll("Test Video Title Again");
		ArrayList<String> titles = playlist.getPlaylistVideosTitles();
		assertEquals(1, titles.size());
	}

	@Test
	public void testShuffleVideoTitles() {
		Playlist playlist = new Playlist("Test Playlist");
		playlist.addToPlaylist("Test Video Title");
		playlist.addToPlaylist("Test Video Title Again");
		playlist.addToPlaylist("Test Video Title Bro");
		playlist.shuffleVideoTitles(null);
		ArrayList<String> titles = playlist.getPlaylistVideosTitles();
		System.out.println(titles);
	}

	@Test
	public void testAddVideoToDB() {
		Video video = new Video("Test Video Title", "Test Video Description", 15, Genre.Comedy);
		ArrayList<Video> videoDB = new ArrayList<Video>();
		videoDB.add(video);
		assertEquals("Test Video Title", videoDB.get(0).getTitle());
	}

	@Test
	public void testRemoveAllFromDB() {
		Video video = new Video("Test Video Title", "Test Video Description", 15, Genre.Music);
		ArrayList<Video> videoDB = new ArrayList<Video>();
		videoDB.add(video);
		videoDB.removeAll(videoDB);
		assertEquals(0, videoDB.size());
	}
	
	@Test
	public void testAddComments() {
		Video video = new Video("Test Video Title", "Test Video Description", 15, Genre.Music);
		video.addComments("This is a comment");
		System.out.print(video.getComments());
	}
	
	@Test
	public void testClearDatabase() {
		TubeVideosManager manager = new TubeVideosManager();
		manager.clearDatabase();
		assertEquals(0, manager.getAllVideosInDB().size());
	}
	
	@Test
	public void testCompareToAndEquals() {
		Video video = new Video("Test Video Title", "Test Video Description", 15, Genre.Music);
		Video videoTwo = new Video("Test Video Title", "Test Video Description", 15, Genre.Music);
		Video videoThree = new Video("A Test Video Title ", "Test Video Description", 15, Genre.Music);
		assertEquals(1, video.compareTo(videoThree));
		assertEquals(0, video.compareTo(videoTwo));
		assertFalse(video.equals(videoThree));
	}
	
	@Test
	public void testSearchForVideos() {
		TubeVideosManager manager = new TubeVideosManager();
		Video video = new Video("Test Video Title", "Test Video Description", 15, Genre.Music);
		manager.addVideoToDB("Test Video Title", "Test Video Description", 15, Genre.Music);
		Playlist playlist = new Playlist("Test PLaylist Title");
		playlist.addToPlaylist(video.getTitle());
		System.out.print(manager.searchForVideos(video.getTitle(), video.getUrl(), video.getDurationInMinutes(), video.getGenre()));
	}
}
